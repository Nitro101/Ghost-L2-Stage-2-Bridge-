#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <WiFi.h>
#include <WebServer.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <Preferences.h>

// ---------------- OLED SETTINGS ----------------
#define OLED_WIDTH 128
#define OLED_HEIGHT 64
#define OLED_ADDRESS 0x3C
#define PIN_OLED_SDA 21
#define PIN_OLED_SCL 22

Adafruit_SSD1306 display(OLED_WIDTH, OLED_HEIGHT, &Wire, -1);

// ---------------- BRIDGE SETTINGS ----------------
const char *AP_SSID = "Ghost-L2-Bridge";
const char *AP_PASS = "ghost12345";

WebServer server(80);
String webMessage = "";
unsigned long webMessageUntil = 0;

// ---------------- PAIRED CYDS ----------------
#define MAX_CYDS 8

struct CydDevice {
  uint8_t mac[6];
  char name[24];
  bool paired;
  unsigned long lastSeen;
};

CydDevice cyds[MAX_CYDS];
int cydCount = 0;

// ---------------- OLED ----------------
void drawOLED() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);

  display.setCursor(0, 0);
  display.println("GHOST L2 BRIDGE");

  display.setCursor(0, 16);
  display.println("WIFI: READY");

  display.setCursor(0, 28);
  display.println("ESP-NOW: READY");

  display.setCursor(0, 40);
  display.println("NRF24: COMING NEXT");

  display.setCursor(0, 52);
  display.printf("CYDS: %d", cydCount);

  display.display();
}

// ---------------- WEB PAGE ----------------
String css() {
  String x;
  x += "<style>";
  x += "*{box-sizing:border-box}";
  x += "body{font-family:Arial;background:#0b1220;color:#e5e7eb;margin:0;padding:20px}";
  x += ".box{background:#121b2c;padding:20px;margin-bottom:20px;border-radius:12px;border:1px solid #23324a}";
  x += "h1,h2,h3{color:#22d3ee}";
  x += "h1{margin-top:0}";
  x += "label{display:block;margin-top:12px}";
  x += "input,select{width:100%;padding:12px;margin-top:5px;box-sizing:border-box;background:#1a2438;color:white;border:1px solid #2f425e;border-radius:8px}";
  x += "button{padding:12px 20px;margin-top:15px;border:0;border-radius:8px;background:#22d3ee;color:#06202a;font-weight:bold}";
  x += ".danger{background:#ef4444;color:white}";
  x += ".good{color:#34d399}";
  x += ".bad{color:#f87171}";
  x += ".warn{color:#fbbf24}";
  x += ".small{font-size:13px;color:#94a3b8}";
  x += "</style>";
  return x;
}

void dashboardPage() {
  String x;
  x += "<!DOCTYPE html><html><head><meta charset='UTF-8'>";
  x += "<meta name='viewport' content='width=device-width,initial-scale=1'>";
  x += "<title>Ghost L2 Bridge</title>";
  x += css();
  x += "</head><body>";
  x += "<h1>Ghost L2 Bridge</h1>";

  x += "<div class='box'><h2>Bridge Status</h2>";
  if (webMessage.length() && millis() < webMessageUntil) {
    x += "<p><b>" + webMessage + "</b></p>";
  }
  x += "<p>Wi-Fi: <span class='good'>READY</span></p>";
  x += "<p>ESP-NOW: <span class='good'>READY</span></p>";
  x += "<p>NRF24: <span class='warn'>COMING NEXT</span></p>";
  x += "<p>Connected CYDs: <b>" + String(cydCount) + "</b></p>";
  x += "</div>";

  x += "<div class='box'><h2>Paired CYD Consoles</h2>";
  if (cydCount == 0) {
    x += "<p class='small'>No CYD consoles paired yet.</p>";
  }
  for (int i = 0; i < cydCount; i++) {
    x += "<p><b>" + String(cyds[i].name) + "</b><br>";
    char macStr[18];
    sprintf(macStr, "%02X:%02X:%02X:%02X:%02X:%02X",
            cyds[i].mac[0], cyds[i].mac[1], cyds[i].mac[2],
            cyds[i].mac[3], cyds[i].mac[4], cyds[i].mac[5]);
    x += String(macStr) + "</p>";
  }
  x += "</div>";

  x += "<div class='box'><h2>Pairing</h2>";
  x += "<p class='small'>CYD consoles send pairing requests over ESP-NOW. Accepted consoles appear above.</p>";
  x += "</div>";

  x += "</body></html>";
  server.send(200, "text/html", x);
}

// ---------------- ESP-NOW PAIRING ----------------
typedef struct {
  char cydName[24];
} PairingRequest;

void onEspNowReceive(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  if (len != sizeof(PairingRequest)) {
    return;
  }

  PairingRequest request;
  memcpy(&request, data, sizeof(PairingRequest));

  for (int i = 0; i < cydCount; i++) {
    if (memcmp(cyds[i].mac, info->src_addr, 6) == 0) {
      cyds[i].lastSeen = millis();
      return;
    }
  }

  if (cydCount >= MAX_CYDS) {
    Serial.println("BRIDGE: CYD LIST FULL");
    return;
  }

  memcpy(cyds[cydCount].mac, info->src_addr, 6);
  strncpy(cyds[cydCount].name, request.cydName, sizeof(cyds[cydCount].name) - 1);
  cyds[cydCount].name[sizeof(cyds[cydCount].name) - 1] = '\0';
  cyds[cydCount].paired = true;
  cyds[cydCount].lastSeen = millis();
  cydCount++;

  Serial.printf("BRIDGE: CYD PAIRED: %s\n", cyds[cydCount - 1].name);
  webMessage = "CYD PAIRED: " + String(cyds[cydCount - 1].name);
  webMessageUntil = millis() + 3000;
  drawOLED();
}

// ---------------- SETUP ----------------
void setup() {
  Serial.begin(115200);

  Wire.begin(PIN_OLED_SDA, PIN_OLED_SCL);
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS)) {
    Serial.println("BRIDGE: OLED NOT FOUND");
  }

  drawOLED();

  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(AP_SSID, AP_PASS);

  if (esp_now_init() != ESP_OK) {
    Serial.println("BRIDGE: ESP-NOW FAILED");
  } else {
    esp_now_register_recv_cb(onEspNowReceive);
  }

  server.on("/", HTTP_GET, dashboardPage);
  server.begin();

  Serial.println("BRIDGE: STARTED");
  Serial.print("BRIDGE AP IP: ");
  Serial.println(WiFi.softAPIP());
}

// ---------------- LOOP ----------------
void loop() {
  server.handleClient();
}
